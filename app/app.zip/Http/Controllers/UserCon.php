<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Logdata;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserCon extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data['user'] = User::all();
        return view('user', $data);
    }

    public function logdata()
    {
        $data['log'] = Logdata::all();
        return view('logdata', $data);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validasi input
        
        $iduser = Auth::user()->id;
        
        // Menyimpan data ke dalam tabel User menggunakan create()
        User::create([
            'name' => $request->name,
            'status' => $request->status,
            'email' => $request->name . 'xample@gmail.com',
            'password' => Hash::make($request->pw),
        ]);


        Logdata::create([
            'id_user' => $iduser,
            'aktivitas' => 'Menambahkan Data User '. $request->name . ' Status : '. $request->status ,
        ]);

        // Redirect atau response setelah berhasil menyimpan data
        return redirect()->back()->with('success', 'User berhasil ditambahkan.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        // Update data item
        $item = User::find($id);

        if ($request->pw) {
            $item->update([
                'name' => $request->name,
                'status' => $request->status,
                'password' => Hash::make($request->pw),
            ]);
        }else {
            $item->update([
                'name' => $request->name,
                'status' => $request->status,
            ]);
        }

        $id_user = Auth::user()->id;

        Logdata::create([
            'id_user' => $id_user,
            'aktivitas' => 'Mengupdate Data User '. $request->name . ' Status : '. $request->status ,
        ]);

        // Redirect kembali ke halaman list item
        return redirect()->route('user')->with('success', 'User berhasil diupdate');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $item = User::find($id);
        $item->delete();

        $id_user = Auth::user()->id;

        Logdata::create([
            'id_user' => $id_user,
            'aktivitas' => 'Menghapus Data User'. $item->name . ' Status : '. $item->status ,
        ]);

        return redirect()->route('user')->with('success', 'User berhasil dihapus');
    }
}
