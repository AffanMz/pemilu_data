<?php if(app()->environment('local')): ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<?php else: ?>
    <link rel="stylesheet" href="<?php echo e(asset('build/assets/app-7KWvDcDT.css')); ?>">
    <script src="<?php echo e(asset('build/assets/app-CEsE5a7F.js')); ?>" defer></script>
<?php endif; ?><?php /**PATH C:\laragon\www\pemilu_data\resources\views/css-js.blade.php ENDPATH**/ ?>