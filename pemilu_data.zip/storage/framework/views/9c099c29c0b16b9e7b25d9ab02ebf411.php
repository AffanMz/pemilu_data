<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Log Aktivitas</title>
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.1/dist/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('build/assets/app-7KWvDcDT.css')); ?>">
    <script src="<?php echo e(asset('build/assets/app-CEsE5a7F.js')); ?>" defer></script>
</head>
<body>

    <?php
        use App\Models\Penduduk;
        use App\Models\Kelurahan;
        use App\Models\Kecamatan;
        use App\Models\Desa;
    ?>
    
    <?php if (isset($component)) { $__componentOriginal9978fb1500f77af723d2c2e081575b68 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9978fb1500f77af723d2c2e081575b68 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav_side','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav_side'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9978fb1500f77af723d2c2e081575b68)): ?>
<?php $attributes = $__attributesOriginal9978fb1500f77af723d2c2e081575b68; ?>
<?php unset($__attributesOriginal9978fb1500f77af723d2c2e081575b68); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9978fb1500f77af723d2c2e081575b68)): ?>
<?php $component = $__componentOriginal9978fb1500f77af723d2c2e081575b68; ?>
<?php unset($__componentOriginal9978fb1500f77af723d2c2e081575b68); ?>
<?php endif; ?>

    <div class="flex flex-col p-4 pt-20 lg:ml-64">
        <div class="flex flex-col mt-4 rounded-lg dark:border-gray-700">
            <div class="flex w-full justify-between px-4 pb-5 gap-4">
                <h2 class="font-bold text-3xl text-gray-700">Log Aktivitas</h2>
            </div>


            <div class="flex flex-col border p-4 rounded-lg  min-h-[25rem] mb-4 rounde dark:bg-gray-800">
                <div class="w-full rounded-lg overflow-x-auto">
                    <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-blue-300 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" class="px-6 py-3">
                                    No
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    User
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Status
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Wilayah
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Aktivitas
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Tanggal
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!is_null($item->user)): ?>
                                    <tr class="bg-blue-100 border-b dark:bg-gray-800 dark:border-gray-700 font-semibold hover:bg-blue-200 dark:hover:bg-gray-600">
                                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                            <?php echo e($loop->iteration); ?>

                                        </th>
                                        <td class="px-6 py-4">
                                            <?php echo e($item->user->name); ?>

                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($item->user->status); ?>

                                        </td>
                                        <td class="px-6 py-4">
                                            <?php
                                                if ($item->user->status == 'admin') {
                                                    $wilayah = 'Semua Wilayah';
                                                } elseif ($item->user->status == 'editor') {
                                                    $wl = Kecamatan::find($item->user->id_tugas);
                                                    $wilayah = $wl->name;
                                                } else {
                                                    $wl = Kelurahan::find($item->user->id_tugas);
                                                    $wilayah = $wl->kecamatan->name . '-' . $wl->name;
                                                }
                                            ?>
                                            <?php echo e($wilayah); ?>

                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($item->aktivitas); ?>

                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($item->created_at); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
    <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.1/dist/flowbite.min.js"></script>
</html><?php /**PATH C:\laragon\www\pemilu_data\resources\views/logdata.blade.php ENDPATH**/ ?>